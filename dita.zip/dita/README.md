Acquisition Resources
